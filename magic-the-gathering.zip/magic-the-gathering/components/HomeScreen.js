import React from 'react';

const WelcomeScreen = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="relative h-64">
          <img
            src="/api/placeholder/800/400"
            alt="Magic: The Gathering cards"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <h1 className="text-4xl font-bold text-white text-center">
              Magic: The Gathering Companion
            </h1>
          </div>
        </div>
        <div className="p-6">
          <p className="text-gray-700 text-lg mb-4">
            Welcome to your ultimate Commander companion! Track health, manage resources, and explore card interactions with ease.
          </p>
          <div className="flex justify-center">
            <button 
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out"
              onClick={() => console.log('Get Started clicked')}
            >
              Get Started
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomeScreen;