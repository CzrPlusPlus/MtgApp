import React, { useState, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions, FlatList, Modal } from 'react-native';
import { GestureHandlerRootView, PanGestureHandler, State } from 'react-native-gesture-handler';
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const LifeCounter = ({ life, setLife, color, player }) => {
  const onGestureEvent = ({ nativeEvent }) => {
    if (nativeEvent.state === State.ACTIVE) {
      if (nativeEvent.translationY > 20) {
        setLife(prevLife => ({ ...prevLife, [player]: prevLife[player] - 1 }));
      } else if (nativeEvent.translationY < -20) {
        setLife(prevLife => ({ ...prevLife, [player]: prevLife[player] + 1 }));
      }
    }
  };

  return (
    <PanGestureHandler onHandlerStateChange={onGestureEvent}>
      <View style={[styles.lifeCounter, { backgroundColor: color }]}>
        <Text style={styles.playerText}>Player {player}</Text>
        <Text style={styles.lifeText}>{life[player]}</Text>
      </View>
    </PanGestureHandler>
  );
};

const FourPlayerLayout = ({ life, setLife }) => (
  <View style={styles.layoutContainer}>
    <View style={styles.row}>
      <LifeCounter life={life} setLife={setLife} color="#2a3e4f" player={1} />
      <LifeCounter life={life} setLife={setLife} color="#361335" player={2} />
    </View>
    <View style={styles.row}>
      <LifeCounter life={life} setLife={setLife} color="#273b13" player={3} />
      <LifeCounter life={life} setLife={setLife} color="#3b1513" player={4} />
    </View>
  </View>
);

const TwoPlayerLayout = ({ life, setLife }) => (
  <View style={styles.layoutContainer}>
    <LifeCounter life={life} setLife={setLife} color="#2a3e4f" player={1} />
    <LifeCounter life={life} setLife={setLife} color="#361335" player={2} />
  </View>
);

const ThreePlayerLayout = ({ life, setLife }) => (
  <View style={styles.layoutContainer}>
    <View style={styles.row}>
      <LifeCounter life={life} setLife={setLife} color="#2a3e4f" player={1} />
      <LifeCounter life={life} setLife={setLife} color="#361335" player={2} />
    </View>
    <View style={styles.row}>
      <LifeCounter life={life} setLife={setLife} color="#273b13" player={3} />
    </View>
  </View>
);

const LayoutIndicator = ({ currentIndex, totalLayouts }) => (
  <View style={styles.indicatorContainer}>
    {[...Array(totalLayouts)].map((_, index) => (
      <View
        key={index}
        style={[
          styles.indicator,
          currentIndex === index && styles.activeIndicator,
        ]}
      />
    ))}
  </View>
);

const MTGCalculator = () => {
  const navigation = useNavigation();
  const [life, setLife] = useState({ 1: 40, 2: 40, 3: 40, 4: 40 });
  const [currentLayout, setCurrentLayout] = useState(0);
  const [showLayoutOptions, setShowLayoutOptions] = useState(false);
  const flatListRef = useRef(null);

  const handleReset = () => {
    setLife({ 1: 40, 2: 40, 3: 40, 4: 40 });
  };

  const handleBack = () => {
    navigation.goBack();
  };

  const layouts = [
    { key: 'fourPlayer', component: FourPlayerLayout, title: 'Magig 4 ' },
    { key: 'threePlayer', component: ThreePlayerLayout, title: 'Magic 3' },
    { key: 'twoPlayer', component: TwoPlayerLayout, title: 'Magic 2' },
  ];

  const renderLayout = ({ item, index }) => {
    const LayoutComponent = item.component;
    return <LayoutComponent life={life} setLife={setLife} />;
  };

  const handleLayoutChange = (index) => {
    flatListRef.current.scrollToIndex({ index, animated: true });
    setCurrentLayout(index);
    setShowLayoutOptions(false);
  };

  return (
    <GestureHandlerRootView style={styles.container}>
      <FlatList
        ref={flatListRef}
        data={layouts}
        renderItem={renderLayout}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onMomentumScrollEnd={(event) => {
          const newIndex = Math.round(event.nativeEvent.contentOffset.x / width);
          setCurrentLayout(newIndex);
        }}
      />
      <LayoutIndicator currentIndex={currentLayout} totalLayouts={layouts.length} />
      <View style={styles.centerButtonsContainer}>
        <TouchableOpacity style={styles.button} onPress={handleReset}>
          <Text style={styles.buttonText}>Reset</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={handleBack}>
          <Text style={styles.buttonText}>Back</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => setShowLayoutOptions(true)}>
          <Text style={styles.buttonText}>Layouts</Text>
        </TouchableOpacity>
      </View>
      <Modal
        visible={showLayoutOptions}
        transparent={true}
        animationType="slide"
      >
        <View style={styles.modalContainer}>
          {layouts.map((layout, index) => (
            <TouchableOpacity
              key={layout.key}
              style={styles.modalButton}
              onPress={() => handleLayoutChange(index)}
            >
              <Text style={styles.modalButtonText}>{layout.title}</Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity
            style={[styles.modalButton, styles.closeButton]}
            onPress={() => setShowLayoutOptions(false)}
          >
            <Text style={styles.modalButtonText}>Close</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </GestureHandlerRootView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1E1E1E',
  },
  layoutContainer: {
    width,
    height,
    flexDirection: 'column',
  },
  row: {
    flexDirection: 'row',
    flex: 1,
  },
  lifeCounter: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#000',
  },
  playerText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 10,
  },
  lifeText: {
    fontSize: 60,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  centerButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    backgroundColor: 'rgba(44, 44, 44, 0.8)',
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 20,
  },
  button: {
    backgroundColor: '#4A0E4E',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginHorizontal: 5,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  indicatorContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    position: 'absolute',
    bottom: 80,
    left: 0,
    right: 0,
  },
  indicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#888',
    marginHorizontal: 4,
  },
  activeIndicator: {
    backgroundColor: '#FFF',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
  },
  modalButton: {
    backgroundColor: '#4A0E4E',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 5,
    marginVertical: 10,
    width: 200,
    alignItems: 'center',
  },
  modalButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  closeButton: {
    backgroundColor: '#8B0000',
    marginTop: 20,
  },
});

export default MTGCalculator;